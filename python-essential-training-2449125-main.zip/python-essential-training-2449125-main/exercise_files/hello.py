
# Print "hello, world!" to the terminal
print('Hello, World!')